<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<title>Testing HMVC</title>
</head>
 
<body>
 
<h2>This is from the Test HMVC page.</h2>
 
<?php echo Modules::run( 'hmvc/hmvc/embed' ); ?>
 
</body>
</html>