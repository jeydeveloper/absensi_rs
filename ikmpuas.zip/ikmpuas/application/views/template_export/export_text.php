<!DOCTYPE html> 
<html>
	<head>
		<title><?php echo $title; ?></title>
	</head>
	<body style="font-size:12px;">
		<?php echo $contents; ?>
	</body>
</html>